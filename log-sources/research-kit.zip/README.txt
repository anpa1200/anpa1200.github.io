1200km security log-source research kit
Run: python3 scripts/validate-log-sources.py
Preserved publisher examples and pinned upstream parser fixtures. See each catalogue entry for attribution and transformations. No independent capture authenticity or live collector/detection validation is claimed. Text formats have framing checks only. Do not execute content inside samples.
